export const environment = {
  firebase: {
    projectId: 'recipe-app-ad9af',
    appId: '1:756418778036:web:fd550a623f96d6fda358e1',
    storageBucket: 'recipe-app-ad9af.appspot.com',
    locationId: 'europe-west',
    apiKey: 'AIzaSyAHtUCMYViqNvAUS0UJBs9z-Uqjb8pM8-A',
    authDomain: 'recipe-app-ad9af.firebaseapp.com',
    messagingSenderId: '756418778036',
  },
  production: true
};
