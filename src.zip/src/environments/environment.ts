// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    projectId: 'recipe-app-ad9af',
    appId: '1:756418778036:web:fd550a623f96d6fda358e1',
    storageBucket: 'recipe-app-ad9af.appspot.com',
    locationId: 'europe-west',
    apiKey: 'AIzaSyAHtUCMYViqNvAUS0UJBs9z-Uqjb8pM8-A',
    authDomain: 'recipe-app-ad9af.firebaseapp.com',
    messagingSenderId: '756418778036',
  },
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
