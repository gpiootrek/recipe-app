export const RECIPE_URL =
  'https://www.themealdb.com/api/json/v1/1/lookup.php?i=';
export const RANDOM_RECIPE_URL =
  'https://www.themealdb.com/api/json/v1/1/random.php';
export const RECIPES_BY_CATEGORY_URL =
  'https://www.themealdb.com/api/json/v1/1/filter.php?c=';
export const CATEGORIES_URL = 'https://www.themealdb.com/api/json/v1/1/categories.php';
