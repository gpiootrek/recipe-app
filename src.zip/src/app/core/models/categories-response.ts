import { Category } from './category';
import { CategoryDetails } from './category-details';

export interface CategoriesResponse {
  categories: CategoryDetails[];
}
