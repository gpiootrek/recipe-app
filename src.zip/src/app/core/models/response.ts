export interface Response<T> {
  meals: T[];
}
