import { Category } from "./category";

export interface CategoryDetails {
    idCategory: string;
    strCategory: Category;
    strCategoryThumb: string;
    strCategoryDescription: string;
}