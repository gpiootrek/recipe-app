export interface Meal {
    strMeal?: string;
    strMealThumb?: string;
    idMeal?: string;
}