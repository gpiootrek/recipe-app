import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MainRecipeComponent } from './main-recipe.component';

describe('MainRecipeComponent', () => {
  let component: MainRecipeComponent;
  let fixture: ComponentFixture<MainRecipeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MainRecipeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MainRecipeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
